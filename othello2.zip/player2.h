/* Michael Hanna, mwhanna
 * CS 152, Spring 2017
 * Project 2
 */

#ifndef __PLAYER2_H
#define __PLAYER2_H


#include "auxx.h"

/*returns the first valid move for a given turn*/
pos player2(game* g);
                        
#endif