/* Michael Hanna, mwhanna
 * CS 152, Spring 2017
 * Project 2
 */

#ifndef __PLAYER1_H
#define __PLAYER1_H


#include "auxx.h"

/*returns the first valid move for a given turn*/
pos player1(game* g);
                        
#endif